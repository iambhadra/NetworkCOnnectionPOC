package com.bhadra.networkconnectionpoc

interface OnNetworkConnectionChangedListener {
    fun onNetworkConnectionChanged(isConnected: Boolean)
}